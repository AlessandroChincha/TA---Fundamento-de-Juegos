#include "Zombie.h"
#include <random>
#include <ctime>
#include<glm/gtx/rotate_vector.hpp>
Zombie::Zombie()
{
}

Zombie::~Zombie()
{
}

void Zombie::init(float speed, glm::vec2 position)
{
	this->speed = speed;
	this->position = position;
	color.set(0, 255, 0, 255);
	std::mt19937 randomEngine(time(nullptr));
	std::uniform_real_distribution<float>randDir(-1.0f, 1.0f);
	PositionZ = glm::vec2(randDir(randomEngine), randDir(randomEngine));
	if (PositionZ.length() == 0) {
		PositionZ = glm::vec2(1.0f, 0.0f);
	}
}

void Zombie::update(vector<string>& levelData, vector<Human*>& humans, vector<Zombie*>& zombies)
{
	std::mt19937 randomEngine(time(nullptr)); 
	std::uniform_real_distribution<float> randRotate(-40.0f, 40.0f); 
	position += PositionZ * (speed * 2.0f); 

	//Si colisiona, se cambie de rumbo
	if (collideWithLevel(levelData))
	{
		PositionZ.x = -PositionZ.x;
		PositionZ.y = -PositionZ.y;
	}
}
