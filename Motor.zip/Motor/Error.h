#pragma once
#include <string>
extern void fatalError(std::string errorString);

