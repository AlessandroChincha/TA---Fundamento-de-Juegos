#pragma once
#include "Agent.h"
class Zombie :
    public Agent
{
private:
    //float _speed;
    glm::vec2 PositionZ;
public:
    Zombie();
    ~Zombie();
    void init(float speed, glm::vec2 position);
    void update(vector<string>& levelData,vector<Human*>& humans,vector<Zombie*>& zombies);
};

