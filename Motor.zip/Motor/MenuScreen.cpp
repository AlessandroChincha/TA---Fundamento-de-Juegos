#include "MenuScreen.h"

MenuScreen::MenuScreen(Window* window)
{
    this->window = window;
}

void MenuScreen::build()
{
}

void MenuScreen::destroy()
{
}

void MenuScreen::onExit()
{
}

void MenuScreen::onEntry()
{
}

void MenuScreen::update()
{
}

void MenuScreen::draw()
{
}

void MenuScreen::checkInput()
{
}

int MenuScreen::getNextScreen() const
{
    return 0;
}

int MenuScreen::getPreviousScreen() const
{
    return 0;
}

MenuScreen::~MenuScreen()
{
}
